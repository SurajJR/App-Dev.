#include "stdafx.h"

#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<fstream>
#include<string.h>
#include<process.h>
#include<stdlib.h>
#include<random>
#include<time.h>
#include<amp_graphics.h>
#include<dos.h>
#include<mmsystem.h>
#include<atlalloc.h>
#include<concrt.h>
//

using namespace std;

void sleeppc()
{
	Concurrency::wait(5000);

}

/*void mou()
{
union REGS i, o;
i.x.ax = 1;
int86(0x33, &i, &o);
}*/

/*void loadbar()
{
int count = 50,b=0,random_integer;
int lowest = 1, highest = 10;
int range = (highest - lowest) + 1;
while (count--)
{
random_integer = lowest + int(range*rand() / (RAND_MAX + 10));
b = random_integer;
sound(10 * b);
delay(75);
nosound();
textattr(random(16) + 'b' + BLINK);
cout<<"*";
}

}*/
void casino()
{
	_RANDOM_
		_Random_device;
	char password[20], username[20], a, user[20], pass[20], f[20];
	unsigned long long buyin; int j = 0;
	fstream fin, fout;
	int random_integer;
	int lowest = 1, highest = 10;
	int range = (highest - lowest) + 1;
go:	system("cls");
	cout << "\n Are you a Existing User (Y/N): ";
	cin >> a;
	if (a == 'y' || a == 'Y')
	{
		int i = 0, m = 0;
		cout << "\n Enter User-Name: ";
		std::cin >> username;
		strcpy_s(f, username);
		strcat_s(f, "c.txt");
		fin.open(f, ios::in | ios::_Nocreate);
		fin >> user;
		fin >> pass;
		fin >> buyin;
		{
			if (strcmp(user, username) == 0)
			{
			lable:
				cout << "\n Enter Password: ";
				std::cin >> password;
				/*while (password[m-1]!='\r')
				{
				password[m] = _getch();
				cout << "*";
				m++;
				}*/
			}
			else
			{
				cout << "\n Wrong User-Name!!!\n\tTry Again!!";
				goto go;
			}
			if (strcmp(pass, password) == 0)
			{
				cout << "\n\t\tWELCOME!!\n";
				fin.close();
			}
			else
			{
				cout << "\n Wrong Password!!!!\n\tTry Again!!";
				i++;
				if (i == 3)
				{
					fin.close();
					goto go;
				}
				else
					goto lable;
			}
		}
	}
	else
	{
		j++;
		cout << "\n Enter New User-Name: ";
		std::cin >> username;
		strcpy_s(f, username);
		strcat_s(f, "c.txt");
		fout.open(f, ios::out);
		cout << "\n Enter New Password: ";
		std::cin >> password;
		cout << "\n Enter Your Buyin Amount: ";
		cin >> buyin;
		fout << username << " ";
		fout << password << " ";
		fout << buyin << " ";
		cout << "\n New User Created!!";
		system("pause");
		system("cls");
		fout.close();
		goto go;
	}
	//randomize();
	system("cls");
	/*cout << "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
	cout << "\n                           WELCOME TO CASINO ROYALE";
	cout << "\n\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$";
	//fin.open("details.dat",ios::in,ios::cur);
	*/
	int no, comp = 0, level = 1;
	unsigned long long bid;
	unsigned long long amt = buyin;
	char e;
	do
	{
		cout << "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
		cout << "\n                           WELCOME TO CASINO ROYALE";
		cout << "\n\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$";
		level = amt / 10000;
		cout << "\nYour Account Balance is: " << amt;
		cout << "\n\t\t\t\t\t\t\t\tYour Level is: " << level;
		cout << "\n Enter a Number you want to Bid on (1-10): ";
		cin >> no;
		random_integer = lowest + int(range*rand() / (RAND_MAX + 10));
		while (comp == 0)
			//comp = random(3);
			comp = random_integer;
	back:
		cout << "\n Enter the Bid Amount : ";
		cin >> bid;
		if (amt<bid)
		{
			cout << "\n\t\t\t\t\t Bid Amount is More than Balance!!!!\n\t\t\t\t\n\tStay in Your Limits!!";
			goto back;
		}
		if (comp == no)
		{
			cout << "\n You won!!\n";
			fout.open(f, ios::out);
			amt += bid;
			cout << "Congratulation, Level UP!!\n";
			cout << "Level: " << level;
			fout << username << " ";
			fout << password << " ";
			fout << amt << " ";
			fout << level << " ";
			buyin = amt;
		}
		else
		{
			cout << "\nSorry You Lost :(";
			amt -= bid;
			/*fout.open(f, ios::out);
			fout << username << " ";
			fout << password << " ";
			fout << amt << " ";
			fout << level << " ";
			buyin = amt;*/
		}
		cout << "\n Do You Want to Continue (y,n): ";
		cin >> e;
		system("cls");
	} while (e == 'y' || e == 'y');
	if (e != 'y' || e != 'Y')
	{
		//cout << "\n your balance is" << amt;
		fout.open(f, ios::out);
		fout << username << " ";
		fout << password << " ";
		fout << amt << " ";
		fout << level << " ";
		fout.close();
	}
	cout << "\n--------------------------------------------------------------------------------";
	cout << "\n\n\t\t\t\tCASINO ROYALE";
	cout << "\n \n\n\t\t\tYour Balance is: " << amt;
	cout << "\n--------------------------------------------------------------------------------";
	system("pause");
	system("cls");
}
void penalty()
{
	int random_integer;
	int lowest = 1, highest = 9;
	int range = (highest - lowest) + 1;
	//randomize();
	system("cls");
	char password[20], username[20], a, user[20], pass[20], f[20], z;
	fstream fin, fout;
	int game = 0, win = 0, lose = 0, draw = 0;
go:
	cout << "\n are you an Existing User (Y/N): ";
	cin >> a;
	if (a == 'y' || a == 'Y')
	{
		int i = 0;
		cout << "\n Enter User-Name: \n";
		std::cin >> username;
		strcpy_s(f, username);
		strcat_s(f, "p.txt");
		fin.open(f, ios::in | ios::_Nocreate);
		fin >> user;
		fin >> pass;
		fin >> game;
		fin >> win;
		fin >> lose;
		fin >> draw;
		{
			if (strcmp(user, username) == 0)
			{
			lable:
				cout << "\n Enter the Pass-word: ";
				std::cin >> password;
			}
			else
			{
				cout << "\n Wrong User-Name!!";
				fout.open(f, ios::out);
				fout << user << " ";
				fout << pass << " ";
				fout << game << " ";
				fout << win << " ";
				fout << lose << " ";
				fout.close();
				fin.close();
				goto go;
			}
			if (strcmp(pass, password) == 0)
			{
				cout << "\nWelcome!!\n";
				fin.close();
				system("cls");
			}
			else
			{
				cout << "\n Wrong Pass-word!!";
				i++;
				if (i == 3)
				{
					fout.open(f, ios::out);
					fout << user << " ";
					fout << pass << " ";
					fout << game << " ";
					fout << win << " ";
					fout << lose << " ";
					fout << draw << " ";
					fout.close();
					fin.close();
					goto go;
				}
				else
					goto lable;
			}
		}
	}
	else
	{
		cout << "\n Enter New User-Name: ";
		std::cin >> username;
		strcpy_s(f, username);
		strcat_s(f, "p.txt");
		fout.open(f, ios::out);
		cout << "\n Enter New Password: ";
		std::cin >> password;
		fout << username << " ";
		fout << password << " ";
		fout << 0 << " ";
		fout << 0 << " ";
		fout << 0 << " ";
		fout << 0 << " ";
		cout << "\n New User Created!!";
		fout.close();
		goto go;
	}
	int c = 0, d = 0;
	do {
		c = 0;
		d = 0;
		system("cls");
		game++;
		/*cout << "\n You have played " << game-1 << " games.";
		cout << "\n\t\t\t\t\t\t\t\t\t\tGame No.: " << game;
		cout << "\n You Won " << win << " games,";
		cout << "\n You Lost " << lose << " games.";
		cout << "\n You Drew " << draw << " games.\n";
		/*cout << "\t\t\t---------------------------------------\n";
		cout << "\t\t\t ___________________________________ \n";
		cout << "\t\t\t |1              7                2 | \n";
		cout << "\t\t\t |                                  | \n";
		cout << "\t\t\t |                                  | \n";
		cout << "\t\t\t |                                  | \n";
		cout << "\t\t\t |5              8                6 | \n";
		cout << "\t\t\t |                                  | \n";
		cout << "\t\t\t |                                  | \n";
		cout << "\t\t\t |3              9                4 | \n";
		cout << "\t\t\t ____________________________________\n";
		cout << "\t\t\t----------------------------------------\n";
		*/
		int h, b, e, g;
		for (int i = 0;i<3;i++)
		{
			//game++;
			cout << "\n You have played " << game - 1 << " games.";
			cout << "\n\t\t\t\t\t\t\t\t\t\tGame No.: " << game;
			cout << "\n You Won " << win << " games,";
			cout << "\n You Lost " << lose << " games.";
			cout << "\n You Drew " << draw << " games.\n";
			cout << "\t\t** --------------------------------------**\n";
			cout << "\t\t**= ___________________________________   =**\n";
			cout << "\t\t**=  |1              7                2 |  =**\n";
			cout << "\t\t**=  |               |                  |  =**\n";
			cout << "\t\t**=  |               |                  |  =**\n";
			cout << "\t\t**=  |               |                  |  =**\n";
			cout << "\t\t**=  |5              8                6 |  =**\n";
			cout << "\t\t**=  |               |                  |  =**\n";
			cout << "\t\t**=  |               |                  |  =**\n";
			cout << "\t\t**=  |3              9                4 |  =**\n";
			cout << "\t\t**=  ____________________________________  =**\n";
			cout << "\t\t**---------------------------------------**\n";
			cout << "\n\t\tPLAYER PENALTY NO." << i + 1;
			cout << "\n ENTER WHERE U WANT TO SCORE:";
			cin >> h;
			if (h>9 || h == 0)
				goto back;
			random_integer = lowest + int(range*rand() / (RAND_MAX + 10));
			b = random_integer;
			do {
				if (b == 0)
					random_integer = lowest + int(range*rand() / (RAND_MAX + 10));
				b = random_integer;
			} while (b == 0);
			if (b == h)
				back:
			cout << "\n NICE SAVE \n";
			else
			{
				cout << "\n NICE SHOT \n";
				c++;
			}
			cout << "\t\tCOMPUTER PENALTY NO." << i + 1;
			cout << "\n ENTER WHERE U WANT TO SAVE:";
			cin >> e;
			highest = 7;
			random_integer = lowest + int(range*rand() / (RAND_MAX + 7));
			g = random_integer;
			do {
				if (g == 0)
					random_integer = lowest + int(range*rand() / (RAND_MAX + 7));
				g = random_integer;
			} while (b == 0);
			if (g == e)
				cout << "\n NICE SAVE \n";
			else
			{
				cout << "\n NICE GOAL \n";
				d++;
			}
			cout << c << ":" << d << endl;
			system("cls");
		}
		if (c>d)
		{
			cout << "\n PLAYER WINS";
			win++;
			fout.open(f, ios::out);
			fout << user << " ";
			fout << pass << " ";
			fout << game << " ";
			fout << win << " ";
			fout << lose << " ";
			fout << draw << " ";
		}
		else if (d>c)
		{
			cout << "\n COMPUTER WINS";
			lose++;
			fout.open(f, ios::out);
			fout << user << " ";
			fout << pass << " ";
			fout << game << " ";
			fout << win << " ";
			fout << lose << " ";
			fout << draw << " ";
		}
		else
		{
			cout << "\n MATCH DRAW";
			draw++;
			fout.open(f, ios::out);
			fout << user << " ";
			fout << pass << " ";
			fout << game << " ";
			fout << win << " ";
			fout << lose << " ";
			fout << draw << " ";
		}
		cout << "\n Do you want to Play Again (Y/N): ";
		cin >> z;
		system("cls");
	} while (z == 'y' || z == 'Y');
}
void main()
{
	/*int x = 170, i, g, driver = DETECT, gmode;
	initgraph(&gdriver, &gmode, "c:\tc\bgi");
	settextstyle(DEVICE_DEFAULT_FONT, HORZRES, 2);
	outtextxy(170, 180, "LOADING, PLEASE WAIT");
	for (i = 0;i < 300;i++)
	{
	delay(30);
	line(x, 200, x, 200);
	x++;
	}
	*/
	cout << "\n\n\n\t\t\t\t---------\n";
	cout << "\t\t\t\tLOADING...";
	sleeppc();
	cout << "\n\n\tWelcome to EPIC GAME LAUNCHER. Enjoy playing our games. ";
	cout << "\n\n\nFor queries/feedback, please contact any of the following developers-";
	cout << "\nBhavesh Bhansali- +91 89043 44469\nSuraj JR- +91 97414 31625\n\n\t\t";
	system("pause");
	system("cls");
	int choice;
	cout << "\n\t\t       :::::::::::::::::::::::::::::::::::::::::";
	cout << "\n\t\t     //     =======  ======   ======    =====   \\";
	cout << "\n\t\t     ::    ||       ||    ||    ||    //        ::";
	cout << "\n\t\t     ::    ||       ||    //    ||    ||        ::";
	cout << "\n\t\t     ::    |======  ||===//     ||    ||        ::";
	cout << "\n\t\t     ::    ||       ||          ||    ||        ::";
	cout << "\n\t\t     ::    ||       ||          ||    ||        ::";
	cout << "\n\t\t     ::    ||       ||          ||    \\         ::";
	cout << "\n\t\t     ::     =====   ||        ======    =====   ::";
	cout << "\n\t\t     ::                   GAMES                 ::";
	cout << "\n\t\t     ::                    INC.                 ::";
	cout << "\n\t\t     ::              ----------------           ::";
	cout << "\n\t\t      *                ------------             * ";
	cout << "\n\t\t       *                 --------              *";
	cout << "\n\t\t        *                 ------              *";
	cout << "\n\t\t         *___________________________________*\n\n\n\t\t\t";
	system("pause");

	system("cls");
	/*cout<<"\n\n_______________________________________________________________________________";
	cout << "\n				  EPIC GAMES INC.                               \n ";
	cout <<"______________________________________________________________________________";
	cout << "\n\n\tChoose any one of the following options:\n\n";
	*/
	do {
		cout << "\n\n_______________________________________________________________________________";
		cout << "\n				  EPIC GAMES INC.                               \n ";
		cout << "______________________________________________________________________________";
		cout << "\n\n\tChoose any one of the following options:\n\n";
		cout << "\n\t 1.CASINO ROYALE\n\t 2.PENALTY SHOOTOUT \n\t 3.EXIT GAME APPLICATION";
		cout << "\n\n Make Your Decision: ";
		cin >> choice;
		switch (choice)
		{
		case 1:casino();
			break;
			cout << "\n\n\n\n\n\t\t\t\tTHANK YOU!!!!!\n";
		case 2:penalty();
			break;
		case 3:system("cls");
			cout << "\n\t\t\tHope You Liked Our Application!!\n\n\n\n\n\n";
			system("pause");
			exit(0);
		}
		system("cls");
	} while (choice != 3);
	system("pause");
}



